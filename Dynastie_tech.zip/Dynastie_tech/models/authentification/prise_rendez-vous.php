<?php

     function inscription($nom,$prenom,$sexe,$age,$telephone,$adresse,$lieu_depart,$lieu_arriver,$email,$accompagnateur,$date_depart,$date_retour,$message ){
            
     $connexion = connecter_db();

     // Inscription de membres
    $req = $connexion->prepare("INSERT INTO prise_rendez_vous(nom,prenom,sexe,age,telephone,adresse,lieu_depart,lieu_arriver,email,accompagnateur,date_depart,date_retour,message,date_envoi) values(?,?,?,?,?,?,?,?,?,?,?,?,?,now())");

    $req->execute([$nom,$prenom,$sexe,$age,$telephone,$adresse,$lieu_depart,$lieu_arriver,$email,$accompagnateur,$date_depart,$date_retour,$message]);
     }
?>  