<?php 
    require_once("../../models/model_general.php");

    require_once("../../models/authentification/inscription.php");
    session_start();
    extract($_POST);
    extract($_GET);
    $password = md5($password);
    
    if($statu=="particulier")
    {
        $raisonsociale = "";
        $secteur_activite = null;
    }
    else
    {
        
        $nom=null;
        $prenom=null;
        $sexe=null;

    }


        // Inscription de l'utilisateur
        // $req = $connexion->prepare("INSERT INTO utilisateurs(nom,prenom,raisonsociale,ville,code_postal,email,password,telephone,secteur_activite,statu,sexe,image_profil,date_enregistrement) values(?,?,?,?,?,?,?,?,?,?,?,now())");
        // $req->execute([$nom,$prenom,$raisonsociale,$ville,$code_postal,$email,$password,$telephone,$secteur_activite,$statu,$sexe,$image_profil]);

    $image_profil = "inconnu.png";

    // try
    // {
    //     $bdd = new PDO('mysql:host=localhost;dbname=doncoeur', 'root', '');
    // }catch(Exception $e)
    // {
    //     die('Erreur : '.$e->getMessage());
    // }

    // $req = $bdd->prepare('INSERT INTO utilisateurs(nom,prenom,raisonsociale,ville,code_postal,email,password,telephone,secteur_activite,statu,sexe,image_profil,date_enregistrement) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, now())'); 
    // $req->execute(array(
    //     $nom,$prenom,$raisonsociale,$ville,$code_postal,$email,$password,$telephone,$secteur_activite,$statu,$sexe,$image_profil
    // ));
    


    inscription($nom,$prenom,$raisonsociale,$ville,$code_postal,$email,$password,$telephone,$secteur_activite,$statu,$sexe);

    echo "Inscription terminé";


    header('location:../../views/autentification/connexion.php');

?>