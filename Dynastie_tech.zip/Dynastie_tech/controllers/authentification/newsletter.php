<?php 
    require_once("../../models/model_general.php");

    require_once("../../models/authentification/newsletter.php");

    extract($_POST);
    extract($_GET);

    inscription($email);
 
   header('location:../../views/index.php');
?>