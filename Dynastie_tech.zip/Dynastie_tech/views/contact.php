
   <?php  
     require_once("../models/model_general.php");

     require_once("../models/authentification/prise_rendez-vous.php");
     include("header.php");
     
    //  compter_visiter($_SERVER['REMOTE_ADDR'],"adhesion");

    //   $pays = all("pays");
  ?>
    


    
    <div class="breadcrumb-area bg-info" data-bgimage="" data-black-overlay="4"> <img src="assets/images/slider/breadcrumb-bg-801.jpg" height="100%" alt=""> 
        
        <div class="container">
            <div class="in-breadcrumb ">
                <div class="row">
                    <div class="col">
                        <h3>Contactez-Nous </h3>
                        <!-- breadcrumb-list start -->
                        <ul class="breadcrumb-list">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active">Contact</li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// Breadcrumb -->
    <br>
 <div>   <H3 class="text-center  ">Contactez Optimum Ambulance pour votre transport médical: 01 53 14 00 86</H3></div>
    
    <!-- Page Conttent -->
    <main class="page-content section-ptb">
       <div class="container">
            <div class="row">
                <div class="col-lg-7 col-sm-12">
                    <div class="contact-form">
                        <div class="contact-form-info">
                            <div class="contact-title">
                                <h3 class="text-info">Laissez nous un Message </h3>

                            </div>
                            <form action="../controllers/authentification/contact.php?" method="post"  >

                               <div class="contact-page-form">
                                   <div class="contact-input">
                                        <div class="contact-inner">
                                            <input data-parsley-minlength="3" name="nom" type="text" placeholder="Votre Nom  *" id="Votre Nom ">
                                        </div>
                                        <div class="contact-inner">
                                            <input data-parsley-minlength="4" name="prenom" type="text" placeholder="Votre Prenom *" id="Votre Prenom ">
                                        </div>
                                        <div class="contact-inner">
                                            <input type="text" placeholder="Email *" id="email" name="email">
                                        </div>
                                        <div class="contact-inner">
                                            <input name="objet" type="text" placeholder="Objet *" id="subject">
                                        </div>
                                        <div class="contact-inner contact-message">
                                            <textarea name="message"  placeholder="Message *"></textarea>
                                        </div>

                                  
                                        
                                    </div>



                                    
                                    <div class="contact-submit-btn">
                                        <button class="submit-btn" type="submit">Envoyer votre Email</button>
                                        <p class="form-messege"></p>
                                    </div>
                               </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-sm-12">
                    <div class="contact-infor">
                        <div class="contact-title">
                            <h3 class="text-danger">Nous contacter</h3>
                        </div>
                        <div class="contact-dec">
                            <p>Entrez vos informations et votre message dans le formulaire ci-dessous nous vous répondrons dans les plus brefs délais.</p>
                        </div>
                        <div class="contact-address">
                            <ul>
                                <li><i class="fa fa-home"></i> Adress:162 Boulevard Stalingrad , 94200 Ivri sur-Seine</li>
                                <li><i class="fa fa-envelope"target="_blank"></i>Optimum ambulance.com</li>
                                <li><i class="fa fa-phone"target="_blank"></i> +33 01 53 14 00 86</li>
                            </ul>
                        </div>
                        <div class="work-hours">
                            <h6><strong>Toujours Disponible</strong></h6>
                            <p><strong>Disponible</strong>: &nbsp; Lun - Dim  Ouvert 24 heures sur 24,
                            7jours/7</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

<div class="text-center">
<map name="">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2627.7823445791814!2d2.374554915672511!3d48.8051325792823!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e673c581c0e371%3A0x5ca9e2fa4e34c801!2s162%20Bd%20de%20Stalingrad%2C%2094200%20Ivry-sur-Seine!5e0!3m2!1sfr!2sfr!4v1655252916034!5m2!1sfr!2sfr" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

</map>

</div>
<br><br>




    <!--// Page Conttent -->
    
    <!-- Footer Area -->
>
        </div><!--// Footer Top Area -->
        
        <?php include("footer.php")?>