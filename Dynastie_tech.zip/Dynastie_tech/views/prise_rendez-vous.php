
   <?php  
     require_once("../models/model_general.php");

     require_once("../models/authentification/prise_rendez-vous.php");
     include("header.php");
     
    //  compter_visiter($_SERVER['REMOTE_ADDR'],"adhesion");

    //   $pays = all("pays");
  ?>

    <div class="breadcrumb-area bg-secondary" data-bgimage="" data-black-overlay="4"> <img src="../assets/images/slider/breadcrumb-bg-801.jpg" height="100%" alt=""> 
        
        <div class="container">
            <div class="in-breadcrumb ">
                <div class="row">
                    <div class="col">
                        <h3>Demande de prise de rendez-vous </h3>
                        <!-- breadcrumb-list start -->
                        <ul class="breadcrumb-list">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active">Prise de rendez-vous</li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// Breadcrumb -->
    <br>
    
    
    <!-- Page Conttent -->
    <main class="page-content section-ptb">
       <div class="container">
            <div class="row">
                <div class="col-lg-7 col-sm-12">
                    <div class="contact-form">
                        <div class="contact-form-info">
                            <div class="contact-title">
                                <h3 class="text-info">Merci de bien remplir le formulaire  </h3>
                            </div>
   
                            <form action="../controllers/authentification/prise_rendez-vous.php?" method="post"  >
                               <div class="contact-page-form">
                                   <div class="contact-input">

                                        <div class="contact-inner">
                                            <input  name="nom" type="text" placeholder="Nom du patient(e)  *" id="nom" required>
                                        </div>
                                        <div class="contact-inner">
                                            <input name="prenom" type="text" placeholder="Prenom du patient(e)  *" id="prenom" required>
                                        </div>


                                        <div class="contact-inner">
                                           <select id="inputState" name="sexe"   id="sexe"  class="form-control" placeholder="Complété votre sexe"required>
                                             <option selected>Complété le sexe</option>
                   
                                              <option value="Masculin">Masculin</option>
                                              <option value="Feminin">Feminin</option>
                     
                                            </select>
                                       </div> 

                                        <div class="contact-inner">
                                            <input name="age" type="text" placeholder="l'âge du patient(e) *" id="age "required>
                                        </div>

                                        <div class="contact-inner">
                                            <input name="telephone" type="text" placeholder="Telephone *" id="telephone "required>
                                        </div>

                                        <div class="contact-inner">
                                            <input name="adresse" type="text" placeholder="adresse complet d'habitation *" id="adresse "required>
                                        </div>

                                         <div class="contact-inner">
                                                <input name="lieu_depart" type="text" placeholder="Lieu de départ *" id="lieu_depart"required>
                                         </div>

                                         <div class="contact-inner">
                                                <input name="lieu_arriver" type="text" placeholder="Lieu d'arrivé *" id="lieu_arriver" required>
                                         </div>


                                         <div class="contact-inner">
                                                <input name="email" type="email" placeholder="Email *" id="email"email>
                                            </div>  


                                        <div class="contact-inner">
                                            <input name="accompagnateur" type="text" placeholder=" Nom de la personne qui l'accompagne *" id="accompagnateur ">
                                        </div>


                                        <div class="contact-inner">
                                        Date et heure depart
                                         <input name="date_depart" type="datetime-local" placeholder="Date et heure depart *" id="date_depart"required>
                                        </div>

                                        <div class="contact-inner">
                                         Date et heure de retour  
                                            <input name="date_retour" type="datetime-local" placeholder="Date et heure de retour  *"  id="date_retour"required>
                                        </div>


                                        <br>

                                        <div class="contact-inner contact-message">
                                            <textarea name="message"  placeholder="Message Complementaire*"></textarea required>
                                        </div>
                                    </div>

                            <div class="form-check">
                                 <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                 <label class="form-check-label" for="flexCheckDefault"> En cochant cette case, j'accepte les conditions particulières ci-dessous* </label>
                             </div>

                            <br>

                                    <div class="contact-submit-btn">
                                        <button class="submit-btn" type="submit">Envoyer votre Demande</button>
                                        <p class="form-messege"></p>
                                    </div>
                               </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-sm-12">
                <div class="contact-infor">
                        <div class="contact-title">
                            <h3 class="text-danger">Nous contacter</h3>
                        </div>
                        <div class="contact-dec">
                            <p>Entrez vos informations et votre message dans le formulaire ci-dessous nous vous répondrons dans les plus brefs délais.</p>
                        </div>
                        <div class="contact-address">
                            <ul>
                                <li><i class="fa fa-home"></i> Adress:162 Boulevard Stalingrad , 94200 Ivri sur-Seine</li>
                                <li><i class="fa fa-envelope"target="_blank"></i>Optimum ambulance.com</li>
                                <li><i class="fa fa-phone"target="_blank"></i> +33 01 53 14 00 86</li>
                            </ul>
                        </div>
                        <div class="work-hours">
                            <h6><strong>Toujours Disponible</strong></h6>
                            <p><strong>Disponible</strong>: &nbsp; Lun - Dim  Ouvert 24 heures sur 24,
                            7jours/7</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--// Page Conttent -->
    
    <?php include("footer.php")?>