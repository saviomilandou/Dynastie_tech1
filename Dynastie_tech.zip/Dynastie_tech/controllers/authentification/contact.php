<?php 
    require_once("../../models/model_general.php");

    require_once("../../models/authentification/contact.php");

    extract($_POST);
    extract($_GET);

    inscription($nom,$prenom,$email,$objet,$message);
 

    header('location:../../views/message.php');
   
    //  header('location:../../views/index.php');
?>