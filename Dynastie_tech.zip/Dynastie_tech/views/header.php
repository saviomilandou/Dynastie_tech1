<?php  
     require_once("../models/model_general.php");

    //  compter_visiter($_SERVER['REMOTE_ADDR'],"index");
     
    
  ?>

<!doctype html>
<html class="no-js" lang="en">

<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Optimum Ambulances || Societé d'ambulancier  </title>
        <meta name="description" content="OPTIMUM AMBULANCES, société par actions simplifiée, immatriculée sous le SIREN 528978281, est en activité depuis 11 ans. 
        Implantée à IVRY-SUR-SEINE (94200), elle est spécialisée dans le secteur d'activité des ambulances. 
        Son effectif est compris entre 6 et 9 salariés. Sur l'année 2018 elle réalise un chiffre d'affaires de 585 800,00 €. Le total du bilan a augmenté de 11,66 % entre 2017 et 2018.
         Societe.com recense 2 établissements ainsi qu' un mandataire depuis le début de son activité, le dernier événement notable de cette entreprise date du 15-04-2016. 
        Aymon LARIBI est président de l'entreprise OPTIMUM AMBULANCES.">
        <meta name="viewport" content="OPTIMUM AMBULANCES, société par actions simplifiée, immatriculée sous le SIREN 528978281, est en activité depuis 11 ans. 
        Implantée à IVRY-SUR-SEINE (94200), elle est spécialisée dans le secteur d'activité des ambulances.">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon1.JPG">
        
    <!-- CSS 
    ========================= -->
   
    <link rel="stylesheet" href="style.css">
    <!-- Fonts CSS -->

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="../assets/css/plugins.css">
    
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">

    <!--newsletter css-->
    <link rel="stylesheet" href="../assets/css/newsletter.css">

    <!-- Modernizer JS -->
    <script src="../assets/js/vendor/modernizr-3.6.0.min.js"></script>
</head>

<body>

<!-- Main Wrapper Start -->
<div class="main-wrapper">
   
    <header class="header-area">
        <!-- header-top-area -->
        <div class="header-top-area theme-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-12">
                       
                        <!-- top-contact-info -->
                        <div class="top-contact-info hover-two">
                            <ul>
                                <li><a href="tel: +33 01 53 14 00 86"><i class="fa fa-phone"></i> 01 53 14 00 86</a></li>
                                <li><a href="mailto:optimumambulance.com"><i class="fa fa-envelope"></i> optimumambulance.com</a></li>
                            </ul>
                        </div><!--// top-contact-info -->
                        
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="top-info-right">
                           
                            <!-- top-social -->
                            <div class="top-social hover-two">
                                <ul>
                                    <li><a href="https://www.facebook.com/optimum ambulance" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="https://twitter.com/"target="_blank"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://www.instagram.com/"target="_blank"><i class="fa fa-instagram"></i></a></li>
                                 
                                    <li><a href="#"><i class="fa fa-map"></i> 162 BOULEVARD STALINGRAD, 94200 IVRY-SUR-SEINE</a></li>
                                </ul>
                            </div><!--// top-social -->
                           
                            
                           
                        </div>
                    </div>
                </div>
            </div>
        </div><!--// header-top-area -->
        
        <div class="header-bottom-area header-sticky header-sticky">
            <div class="container">
                <div class="row">
                   
                    <div class="col-lg-3 col-md-5 col-6">
                        
                        <!-- logo-area -->
                        <div class="logo-area">
                            <a href="index.php"><img src="../assets/images/logo/logo1.png" width="40px" alt="Optimum ambulance" class="mx-2"><b>OPTIMUM AMBULANCES</b></a>
                        </div><!--// logo-area -->
                        
                    </div>
                    
                    <div class="col-lg-9 col-md-7 col-6">
                        
                        <div class="header-bottom-right">
                            <!-- main-menu -->
                            <div class="main-menu style_03">
                                <nav class="main-navigation">
                                    <ul>
                                        <li class="active"><a href="index.php"> ACCUEIL</a>
                                           
                                        </li>
                                        <li><a href="services.php">NOS SERVICES </a>
                                           <ul class="sub-menu">
                                                <li><a href="services.php">Rendez-vous medicaux</a></li>
                                                <li><a href="services.php">Transport des malades a mobilité reduite.</a></li>
                                                <li><a href="services.php">Transport pour des entrées et sortie en Hospitalisation.</a></li>
                                                <li><a href="services.php">Transport des personnes en maison de retaite.</a></li>
                                                <li><a href="services.php">Rendez-vous medicaux</a></li>
                                                <li><a href="services.php">Ambulancier d'urgence</a></li>
                                            </ul>
                                         </li>
                                       
                                        <li><a href="sommes_nous.php">QUI SOMMES NOUS</a></li>
                                    
                                        <li><a href="prise_rendez-vous.php">PRENDRE RENDEZ-VOUS</a></li>

                                        <li><a href="galerie.php">GALERIE</a></li>
                                        
                                        <li><a href="contact.php">CONTACT</a></li>
                                    </ul>
                                </nav>
                            </div><!--// main-menu -->
                             
                        </div>
                    </div>
                    
                     <div class="col">
                        <!-- mobile-menu start -->
                        <div class="mobile-menu d-block d-lg-none"></div>
                        <!-- mobile-menu end -->
                    </div>
                    
                </div>
            </div>
        </div>
        
    </header>