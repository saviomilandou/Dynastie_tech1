<?php
     include("header.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message de reception du formulaire </title>
</head>
<body>
    
<div class="alert alert-primary  text-center" role="alert" >
 Votre formulaire a bien été envoyé chez <b class="text-primary">Optimum Ambulance</b>. Nous allons vous recontacter pour répondre a votre demande et planifier votre trajet de transport.

</div>

</body>
</html>

