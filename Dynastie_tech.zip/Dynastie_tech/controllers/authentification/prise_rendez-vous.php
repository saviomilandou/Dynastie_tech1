<?php 
    require_once("../../models/model_general.php");

    require_once("../../models/authentification/prise_rendez-vous.php");

    extract($_POST);
    extract($_GET);

    inscription($nom,$prenom,$sexe,$age,$telephone,$adresse,$lieu_depart,$lieu_arriver,$email,$accompagnateur,$date_depart,$date_retour,$message);
 
    // echo "Inscription terminé";

    header('location:../../views/message.php');
   
    //  header('location:../../views/index.php');
?>
