
   <?php  
     require_once("../models/model_general.php");

     require_once("../models/authentification/prise_rendez-vous.php");
     include("header.php");
     
    //  compter_visiter($_SERVER['REMOTE_ADDR'],"adhesion");

    //   $pays = all("pays");
  ?>
    
    
    <!-- Breadcrumb -->
    <div class="breadcrumb-area bg-info" data-bgimage="" data-black-overlay="4"> <img src="assets/images/slider/breadcrumb-bg-801.jpg" height="100%" alt=""> 
        
        <div class="container">
            <div class="in-breadcrumb">
                <div class="row">
                    <div class="col">
                        <h3>Nos Realisations</h3>
                        <!-- breadcrumb-list start -->
                        <ul class="breadcrumb-list">
                            <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                        
                            <li class="breadcrumb-item active">Nos Realisations</li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// Breadcrumb -->
    
   
    <!-- Most Popular Courses Area -->
    <div class="most-popular-courses-area section-ptb">
        <div class="container">
            <div class="row">
                <div class="col-lg-8  ml-auto mr-auto">
                    <div class="section-title-two">
           
                        <h3> Découvrez nos prestations de services </h3>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="single-item_two">
                        <div class="single-item-image overlay-effect">
                            <a href="realisations.php"><img src="../assets/images/courses/ambulance4.jpg" alt="Optimum ambulance"></a>
                            <div class="courses-hover-info">
                                <div class="courses-hover-action">
                                    <div class="courses-hover-thumb">
                                        <img src="../assets/images/teacher/icon.jpg" alt="small images" alt="Optimum ambulance">
                                    </div>
                                    <h4><a href="#">Optimum ambulance</a></h4>
                                    <span class="crs-separator">/</span>
                                    <p>Nos service</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-item-text">
                            <h4><a href="#">Ambulancier d'urgence </a></h4>
                            <p>Réponddre aux appels d’urgences provenant de citoyens nécessitant une attention médicale immédiate.</p>
                            <div class="single-item-content">
                                    <div class="single-item-comment-view">
                                            <span><i class="fa fa-users"></i>69</span>
                                            <span><i class="fa fa-heart"></i>41</span>
                                        </div>
                                        <div class="single-item-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>                          
                                        </div>
                            </div>   
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="single-item_two">
                        <div class="single-item-image overlay-effect">
                            <a href="realisations.php"><img src="../assets/images/courses/ambilance5.jpg" alt="Optimum ambulance"></a>
                            <div class="courses-hover-info">
                                <div class="courses-hover-action">
                                    <div class="courses-hover-thumb">
                                        <img src="../assets/images/teacher/icon.jpg" alt="small images" alt="Optimum ambulance">
                                    </div>
                                    <h4><a href="#">Optimum ambulance</a></h4>
                                    <span class="crs-separator">/</span>
                                    <p>Nos services</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-item-text">
                            <h4><a href="#">Transport des malades pour les longues distances </a></h4>
                            <p>Optumum assure vos trajets en ambulance quelque soit la distance.</p>
                            <div class="single-item-content">
                                    <div class="single-item-comment-view">
                                            <span><i class="fa fa-users"></i>59</span>
                                            <span><i class="fa fa-heart"></i>18</span>
                                        </div>
                                        <div class="single-item-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                          
                                        </div>
                            </div>   
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="single-item_two">
                        <div class="single-item-image overlay-effect">
                            <a href="realisations.php"><img src="../assets/images/courses/ser1.jpg" alt="Optimum ambulance"></a>
                            <div class="courses-hover-info">
                                <div class="courses-hover-action">
                                    <div class="courses-hover-thumb">
                                        <img src="../assets/images/teacher/icon.jpg" alt="small images" alt="Optimum ambulance">
                                    </div>
                                    <h4><a href="#">Optimum ambulance</a></h4>
                                    <span class="crs-separator">/</span>
                                    <p>Nos service</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-item-text">
                            <h4><a href="services.php">Transport des personnes en maison de retaite   </a></h4>
                            <p>Pour le transport de nos séniors habitant dans une résidence pour personnes âgées.</p>
                            <div class="single-item-content">
                               <div class="single-item-comment-view">
                                   <span><i class="fa fa-users"></i>52</span>
                                   <span><i class="fa fa-heart"></i>28</span>
                               </div>
                               <div class="single-item-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                 
                               </div>
                            </div>   
                        </div>
                    </div>
                </div>
                <!-- <div class="col-md-12 col-sm-12 text-center mt-50">
                    <a href="course-grid.php" class="button-default button-large">Browse All Courses</a>
                </div> -->
            </div>
            
        </div>
     </div>




<br>

<div class="row">
                <div class="col-lg-4  col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-our-blog mt--30">
                        <div class="our-blog-image">
                            <a href="blog-details.php">
                                <img src="../assets/images/courses/ambulance2.png"  alt="Optimum ambulance">
                                <span class="in-our-blog-icon">
                                    <img src="../assets/images/teacher/icon.jpg"  alt="Optimum ambulance">
                                </span>
                            </a>
                        </div>
                        <div class="our-blog-contnet">
                            <h5><a href="#">Rendez-vous medicaux </a></h5>
                         
                               <p>Vos Déplacements Médicaux assurés en toute Sécurité ! Contactez <a href="">Optimum Ambulance</a></p>
   
                            <div class="button-block">
                              <b><a href="#" class="botton-border"data-toggle="modal" data-target="#exampleModal">Voir Détail</a></b>
                            </div>

                              <!-- Modal -->
                               <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel">Optimum Ambulance </h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                    <p>Pour toutes les personnes désirant se rendre à des rendez-vous médicaux, à une clinique pour une hospitalisation ou chez le kinésithérapeute pour une rééducation, nous mettons à disposition des Véhicules Sanitaires Légers (VSL) leur permettant de se déplacer dans des conditions optimales</p>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
 
                                    </div>
                                  </div>
                                </div>
                              </div> 


                        </div>
                    </div><!--// single-courses -->
                </div>
                
                <div class="col-lg-4  col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-our-blog mt--30">
                        <div class="our-blog-image">
                            <a href="blog-details.php">
                                <img src="../assets/images/courses/ambulance.jpg" alt="">
                                <span class="in-our-blog-icon">
                                    <img src="../assets/images/teacher/icon.jpg" alt="">
                                </span>
                            </a>
                            
                        </div>
                        <div class="our-blog-contnet">
                            <h5><a href="#">Transport des malades a mobilité reduite.</a></h5>
                           <p>Lillum nisi sit porro soluta, officiis odit 
                            <div class="button-block">
                               <b> <a href="#" class="botton-border"data-toggle="modal" data-target="#modelduModal">Voir Détail</a></b>
                            </div>

                        </div>
                    </div><!--// single-courses -->
                </div>
                
        
                           <!-- Modal -->
                           <div class="modal fade" id="modelduModal" tabindex="-1" role="dialog" aria-labelledby="modelduModalLongTitle" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                  <div class="modal-content">
                                       <div class="modal-header" >
                                          <h5 class="modal-title" id="modelduModalLongTitle"> Optimum Ambulance<i class="fa fa-help"></i></h5>
                                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                          </button>
                                       </div>
                                       <div class="modal-body ">
                                       Transport des malade pour une longue distance. <b>optimum ambulance </b>vous transporte en toute sécurité
                                      </div>

                                        <div class="modal-footer">

                                         <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
         
                                        </div>
                                    </div>
                                </div>
                            </div>

                <div class="col-lg-4  col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-our-blog mt--30">
                        <div class="our-blog-image">
                            <a href="blog-details.php">
                                <img src="../assets/images/courses/ambulanec6.png"  alt="Optimum ambulance">
                                <span class="in-our-blog-icon">
                                    <img src="../assets/images/teacher/icon.jpg"  alt="Optimum ambulance">
                                </span>
                            </a>
                            
                        </div>
                        <div class="our-blog-contnet">
                            <h5><a href="#">Transport pour des entrées et sortie en Hospitalisation.</a></h5>
                            <div class="post_meta">
                             <p>Lo sitiis ratione dignissimos, aut corporis.</p>
                            </div>

                            <div class="button-block">
                              <b>  <a href="#" class="botton-border"data-toggle="modal" data-target="#newsmodal">Voir Détail</a></b>
                            </div>

                           <!-- Modal -->
                            <div class="modal fade" id="newsmodal" tabindex="-1" role="dialog" aria-labelledby="newsmodalLongTitle" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                  <div class="modal-content">
                                       <div class="modal-header" >
                                          <h5 class="modal-title" id="newsmodalLongTitle">Optimum ambulance<i class="fa fa-help"></i></h5>
                                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                          </button>
                                       </div>
                                       <div class="modal-body">
                                       Transport pour des entrées et sortie en Hospitalisation.  <b>Optimum Ambulance </b> met a votre disposition une équipe des professionnels pour vous accompagner lors de vos trajets.
                                      </div>

                                        <div class="modal-footer">

                                         <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
         
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!--// single-courses -->
                </div>
             <
                <div class="col-lg-12">
                    <div class="all-course-btn">
                     <a href="tel: +33 01 53 14 00 86" class="all-course" target="_blank"><i class="fa fa-phone mx-3"></i>  Appelez-nous </a>   
                    </div>
                </div>
            </div>
           
        </div>
    </div>

<br><br>

    <?php include("footer.php")?>


