<?php include("header.php");?>
    
    <!-- Hero Slider start -->
    <div class="hero-slider">
       
        <div class="hero-slider-active owl-carousel">
           
            <div class="singleSlide" data-black-overlay="3" style="background-size:cover;">
                <div class="itemBg" style="background-size:cover;">
                    <img src="../assets/images/slider/slider1.jpg" alt="Optimum ambulance">
                </div>
                <!-- Hero Content One Start -->
                <div class="container">
                    <div class="hero-content-one">
                        <div class="row">
                            <div class="col"> 
                                <div class="slider-text-info">
                                    <h1><span>Votre santé, notre priorité</span> </h1>
                                    <p class="text-white text-center">Besoin d'une Ambulance en Urgence ? Nous sommes à votre écoute! Bénéficiez d'un transport sécurisé et d'ambulanciers expérimentés près de chez vous. Service irréprochable,intervention 7j/7.</p>
                                    <!-- <a href="don.php" ><img src="assets/images/logo/don.png" width="10px" alt=""></a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Hero Content One End -->
            </div>
            
            <div class="singleSlide" data-black-overlay="3">
                <div class="itemBg">
                    
                    <img src="../assets/images/slider/0034.jpg" alt="Optimum ambulance">
                </div>
                <!-- Hero Content One Start -->
                <div class="container">
                    <div class="hero-content-one">
                        <div class="row">
                            <div class="col"> 
                                <div class="slider-text-info">
                                    <h1><span>Un transport sanitaire en ambulance pour vos déplacements à caractère médical</span> </h1>
                                    <p class="text-white">Le savoir-faire des ambulanciers de Optimum Ambulance,va bien au-delà d’un simple transport de personnes:</p>
                                    <!-- <a href="don.php" ><img src="assets/images/logo/don.png" width="10px" alt=""></a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Hero Content One End -->
            </div>
            
            <div class="singleSlide" data-black-overlay="3">
                <div class="itemBg">
                <img src="../assets/images/slider/slider3.jpg" alt="Optimum ambulance"> 
                </div>
                <!-- Hero Content One Start -->
                <div class="container">
                    <div class="hero-content-one">
                        <div class="row">
                            <div class="col"> 
                                <div class="slider-text-info">
                                    <h1><span>Une équipe de professionnels pour vous accompagner lors de vos trajets </span> </h1>
                                    <!-- <p class="text-white">Besoin d'une Ambulance en Urgence ? Nous sommes à votre écoute ! Bénéficiez d'un transport sécurisé et d'ambulanciers expérimentés près de chez vous.
                                         Service irréprochable. Intervention 7j/7.</p> -->
                                    <!-- <a href="don.php" ><img src="assets/images/logo/don.png" width="10px" alt=""></a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Hero Content One End -->
            </div>
            
        </div>
    </div>
    <!-- Hero Slider end -->
    
    <!-- About Us Area -->
    <div class="about-us-area section-ptb">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about-us-contents">
                               <h3> <span class="mx-1"></span> <span>Optimum ambulance</span></h3>
                               <p>OPTIMUM AMBULANCES, société par actions simplifiée, immatriculée sous le SIREN 528978281, est en activité depuis 11 ans.
                                    Implantée à IVRY-SUR-SEINE (94200), elle est spécialisée dans le secteur d'activité des ambulances. 
                                    Son effectif est compris entre 6 et 9 salariés. Sur l'année 2018 elle réalise un chiffre d'affaires de 585 800,00 €. 
                                    Le total du bilan a augmenté de 11,66 % entre 2017 et 2018.
                                     Societe.com recense 2 établissements ainsi qu' un mandataire depuis le début de son activité, le dernier événement notable de cette entreprise date du 15-04-2016. 
                                   Aymon LARIBI est président de l'entreprise OPTIMUM AMBULANCES </p>

                   <div class="col-lg-12">
                       <div class="all-course-btn">
                        <a href="prise_rendez-vous" class="all-course" target="_blank"><i class="fa fa-phone mx-3"></i>Réservez votre ambulance  </a>   
                      </div>
                    </div>

                    </div>
                </div>
                <div class="col-lg-5 ">
                    <div class="about-us-image text-right">
                        <a href="#" class="popup-youtube"><img src="../assets/images//slider/slider4.jpg" alt="" target="_blank">
                       
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// About Us Area -->
    
    <!-- Most Popular Courses Area -->
    <div class="most-popular-courses-area section-ptb">
        <div class="container">
            <div class="row">
                <div class="col-lg-8  ml-auto mr-auto">
                    <div class="section-title-two">
           
                        <h3> Découvrez nos prestations de services </h3>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="single-item_two">
                        <div class="single-item-image overlay-effect">
                            <a href="realisations.php"><img src="../assets/images/courses/ambulance4.jpg" alt="Optimum ambulance"></a>
                            <div class="courses-hover-info">
                                <div class="courses-hover-action">
                                    <div class="courses-hover-thumb">
                                        <img src="../assets/images/teacher/icon.jpg" alt="small images" alt="Optimum ambulance">
                                    </div>
                                    <h4><a href="#">Optimum ambulance</a></h4>
                                    <span class="crs-separator">/</span>
                                    <p>Nos service</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-item-text">
                            <h4><a href="realisations.php">Ambulancier d'urgence </a></h4>
                            <p>Réponddre aux appels d’urgences provenant de citoyens nécessitant une attention médicale immédiate.</p>
                            <div class="single-item-content">
                                    <div class="single-item-comment-view">
                                            <span><i class="fa fa-users"></i>69</span>
                                            <span><i class="fa fa-heart"></i>41</span>
                                        </div>
                                        <div class="single-item-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>                          
                                        </div>
                            </div>   
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="single-item_two">
                        <div class="single-item-image overlay-effect">
                            <a href="realisations.php"><img src="../assets/images/courses/ambilance5.jpg" alt="Optimum ambulance"></a>
                            <div class="courses-hover-info">
                                <div class="courses-hover-action">
                                    <div class="courses-hover-thumb">
                                        <img src="../assets/images/teacher/icon.jpg" alt="small images" alt="Optimum ambulance">
                                    </div>
                                    <h4><a href="#">Optimum ambulance</a></h4>
                                    <span class="crs-separator">/</span>
                                    <p>Nos services</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-item-text">
                            <h4><a href="realisations.php">Transport des malades pour les longues distances </a></h4>
                            <p>Optumum assure vos trajets en ambulance quelque soit la distance.</p>
                            <div class="single-item-content">
                                    <div class="single-item-comment-view">
                                            <span><i class="fa fa-users"></i>59</span>
                                            <span><i class="fa fa-heart"></i>18</span>
                                        </div>
                                        <div class="single-item-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                          
                                        </div>
                            </div>   
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="single-item_two">
                        <div class="single-item-image overlay-effect">
                            <a href="realisations.php"><img src="../assets/images/courses/ser1.jpg" alt="Optimum ambulance"></a>
                            <div class="courses-hover-info">
                                <div class="courses-hover-action">
                                    <div class="courses-hover-thumb">
                                        <img src="../assets/images/teacher/icon.jpg" alt="small images" alt="Optimum ambulance">
                                    </div>
                                    <h4><a href="#">Optimum ambulance</a></h4>
                                    <span class="crs-separator">/</span>
                                    <p>Nos service</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-item-text">
                            <h4><a href="realisations.php">Transport des personnes en maison de retaite   </a></h4>
                            <p>Pour le transport de nos séniors habitant dans une résidence pour personnes âgées.</p>
                            <div class="single-item-content">
                               <div class="single-item-comment-view">
                                   <span><i class="fa fa-users"></i>52</span>
                                   <span><i class="fa fa-heart"></i>28</span>
                               </div>
                               <div class="single-item-rating">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                 
                               </div>
                            </div>   
                        </div>
                    </div>
                </div>
                <!-- <div class="col-md-12 col-sm-12 text-center mt-50">
                    <a href="course-grid.php" class="button-default button-large">Browse All Courses</a>
                </div> -->
            </div>
            
        </div>
     </div>
     <section class="newsletter">
        <div class="container">
        <div class="row">
        <div class="col-sm-12">
            <div class="content">
                <h3>Inscrivez vous a notre Newsletter</h3>
                <form action="../controllers/authentification/newsletter.php?" method="post"  >
                <div class="input-group">
                    <input name="email" type="email" class="form-control" id="email" placeholder="Entrez un email valide">
                    <span class="input-group-btn">
                    <button class="btn" type="submit">S'inscrire</button>
                    </span>

                </div>
               </form>
            </div>
        </div>
        </div>
        </div>
        </section>
    
            
            
        </div>
    </div>
    <!--// Testimonials Area -->
    
    <!-- Our Blog Area -->
    <div class="our-blog-area section-ptb bg-gray">
        <div class="container">
            <div class="col-lg-8  ml-auto mr-auto">
                <!-- section-title -->
                <div class="section-title-two">
                    <!-- <h4>Parenage</h4> -->
                    <h3>Nous sommes à votre disposition 7j/7 et 24h/24.</h3>
                    <br>
                    <h5>Un transport sanitaire en ambulance pour vos déplacements à caractère médical avec nos ambulanciers diplômés sont à votre service. </h5>
                </div><!--// section-title -->
            </div>


            <div class="row">
                <div class="col-lg-4  col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-our-blog mt--30">
                        <div class="our-blog-image">
                            <a href="blog-details.php">
                                <img src="../assets/images/courses/ambulance2.png"  alt="Optimum ambulance">
                                <span class="in-our-blog-icon">
                                    <img src="../assets/images/teacher/icon.jpg"  alt="Optimum ambulance">
                                </span>
                            </a>
                        </div>
                        <div class="our-blog-contnet">
                            <h5><a href="#">Rendez-vous medicaux </a></h5>
                         
                               <p>Vos Déplacements Médicaux assurés en toute Sécurité ! Contactez <a href="">Optimum Ambulance</a></p>
   
                            <div class="button-block">
                              <b><a href="#" class="botton-border"data-toggle="modal" data-target="#exampleModal">Voir Détail</a></b>
                            </div>

                              <!-- Modal -->
                               <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel">Optimum Ambulance </h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                    <p>Pour toutes les personnes désirant se rendre à des rendez-vous médicaux, à une clinique pour une hospitalisation ou chez le kinésithérapeute pour une rééducation, nous mettons à disposition des Véhicules Sanitaires Légers (VSL) leur permettant de se déplacer dans des conditions optimales</p>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
 
                                    </div>
                                  </div>
                                </div>
                              </div> 


                        </div>
                    </div><!--// single-courses -->
                </div>
                
                <div class="col-lg-4  col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-our-blog mt--30">
                        <div class="our-blog-image">
                            <a href="blog-details.php">
                                <img src="../assets/images/courses/ambulance.jpg" alt="">
                                <span class="in-our-blog-icon">
                                    <img src="../assets/images/teacher/icon.jpg" alt="">
                                </span>
                            </a>
                            
                        </div>
                        <div class="our-blog-contnet">
                            <h5><a href="blog-details.php">Transport des malades a mobilité reduite.</a></h5>
                           <p>Lillum nisi sit porro soluta, officiis odit 
                            <div class="button-block">
                               <b> <a href="#" class="botton-border"data-toggle="modal" data-target="#modelduModal">Voir Détail</a></b>
                            </div>

                        </div>
                    </div><!--// single-courses -->
                </div>
                
        
                           <!-- Modal -->
                           <div class="modal fade" id="modelduModal" tabindex="-1" role="dialog" aria-labelledby="modelduModalLongTitle" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                  <div class="modal-content">
                                       <div class="modal-header" >
                                          <h5 class="modal-title" id="modelduModalLongTitle"> Optimum Ambulance<i class="fa fa-help"></i></h5>
                                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                          </button>
                                       </div>
                                       <div class="modal-body ">
                                       Transport des malade pour une longue distance. <b>optimum ambulance </b>vous transporte en toute sécurité
                                      </div>

                                        <div class="modal-footer">

                                         <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
         
                                        </div>
                                    </div>
                                </div>
                            </div>

                <div class="col-lg-4  col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-our-blog mt--30">
                        <div class="our-blog-image">
                            <a href="#">
                                <img src="../assets/images/courses/ambulanec6.png"  alt="Optimum ambulance">
                                <span class="in-our-blog-icon">
                                    <img src="../assets/images/teacher/icon.jpg"  alt="Optimum ambulance">
                                </span>
                            </a>
                            
                        </div>
                        <div class="our-blog-contnet">
                            <h5><a href="#">Transport pour des entrées et sortie en Hospitalisation.</a></h5>
                            <div class="post_meta">
                             <p>Lo sitiis ratione dignissimos, aut corporis.</p>
                            </div>

                            <div class="button-block">
                              <b>  <a href="#" class="botton-border"data-toggle="modal" data-target="#newsmodal">Voir Détail</a></b>
                            </div>

                           <!-- Modal -->
                            <div class="modal fade" id="newsmodal" tabindex="-1" role="dialog" aria-labelledby="newsmodalLongTitle" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                  <div class="modal-content">
                                       <div class="modal-header" >
                                          <h5 class="modal-title" id="newsmodalLongTitle">Optimum ambulance<i class="fa fa-help"></i></h5>
                                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                          </button>
                                       </div>
                                       <div class="modal-body">
                                       Transport pour des entrées et sortie en Hospitalisation.  <b>Optimum Ambulance </b> met a votre disposition une équipe des professionnels pour vous accompagner lors de vos trajets.
                                      </div>

                                        <div class="modal-footer">

                                         <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
         
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!--// single-courses -->
                </div>
             
                <div class="col-lg-12">
                    <div class="all-course-btn">
                     <a href="tel: +33 01 53 14 00 86" class="all-course" target="_blank"><i class="fa fa-phone mx-3"></i>  Appelez-nous </a>   
                    </div>
                </div>
            </div>
           
        </div>
    </div>
    <!-- Our Blog End -->

    <!-- Footer Area -->
    <?php include("footer.php")?>