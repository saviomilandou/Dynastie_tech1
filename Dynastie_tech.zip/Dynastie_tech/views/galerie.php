
   <?php  
     require_once("../models/model_general.php");

     require_once("../models/authentification/prise_rendez-vous.php");
     include("header.php");
     
    //  compter_visiter($_SERVER['REMOTE_ADDR'],"adhesion");

    //   $pays = all("pays");
  ?>
    
    
    <!-- Breadcrumb -->
    <div class="breadcrumb-area bg-danger" data-bgimage="" data-black-overlay="4"> <img src="../assets/images/slider/breadcrumb-bg-801.jpg" height="100%" alt=""> 
        <div class="container">
            <div class="in-breadcrumb">
                <div class="row">
                    <div class="col">
                        <h3>Notre Garerie </h3>
                        <!-- breadcrumb-list start -->
                        <ul class="breadcrumb-list">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active">galerie</li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
  
    
    <div>
    
    <main class="page-content">
       
        <!--Gallery Area Start-->
        <div class="gallery-area section-pt section-pb-90">
            <div class="container">
                <div class="row">
                    <!--Single Gallery Image Start-->
                    <div class="col-md-4 col-sm-6">
                        <div class="single-gallery-img mb--30">
                            <a href="../assets/images/gallery/gallerie7.jpg" data-fancybox="images"><img src="../assets/images/gallery/gallerie7.jpg" alt="Optimum Ambulance "></a>
                        </div>
                    </div>
                    <!--Single Gallery Image End-->
                    <!--Single Gallery Image Start-->
                    <div class="col-md-4 col-sm-6">
                        <div class="single-gallery-img mb--30">
                            <a href="../assets/images/gallery/gallerie3.jpg" data-fancybox="images"><img src="../assets/images/gallery/gallerie3.jpg" alt="Optimum Ambulance "></a>
                        </div>
                    </div>
                    <!--Single Gallery Image End-->
                    <!--Single Gallery Image Start-->
                    <div class="col-md-4 col-sm-6">
                        <div class="single-gallery-img mb--30">
                            <a href="../assets/images/gallery/gallerie5.jpg" data-fancybox="images"><img src="../assets/images/gallery/gallerie5.jpg" alt="Optimum Ambulance "></a>
                        </div>
                    </div>
                    <!--Single Gallery Image End-->
                    <!--Single Gallery Image Start-->
                    <div class="col-md-4 col-sm-6">
                        <div class="single-gallery-img mb--30">
                            <a href="../assets/images/gallery/gallerie2.jpg" data-fancybox="images"><img src="../assets/images/gallery/gallerie2.jpg" alt="Optimum Ambulance "></a>
                        </div>
                    </div>
                    <!--Single Gallery Image End-->
                    <!--Single Gallery Image Start-->
                    <div class="col-md-4 col-sm-6">
                        <div class="single-gallery-img mb-30">
                            <a href="../assets/images/gallery/gallerie1.jpg" data-fancybox="images"><img src="../assets/images/gallery/gallerie1.jpg" alt="Optimum Ambulance "></a>
                        </div>
                    </div>
                    <!--Single Gallery Image End-->
                    <!--Single Gallery Image Start-->
                    <div class="col-md-4 col-sm-6">
                        <div class="single-gallery-img mb--30">
                            <a href="../assets/images/gallery/gallerie4.jpg" data-fancybox="images"><img src="../assets/images/gallery/gallerie4.jpg" alt="Optimum Ambulance "></a>
                        </div>
                    </div>
                    <!--Single Gallery Image End-->
                    <!--Single Gallery Image Start-->
                    <div class="col-md-4 col-sm-6">
                        <div class="single-gallery-img mb--30">
                            <a href="../assets/images/gallery/gallery7.png" data-fancybox="images"><img src="../assets/images/gallery/gallery7.jpg" alt="Optimum Ambulance "></a>
                        </div>
                    </div>
                    <!--Single Gallery Image End-->
                    <!--Single Gallery Image Start-->
                    <div class="col-md-4 col-sm-6">
                        <div class="single-gallery-img mb--30">
                            <a href="../assets/images/gallery/galler.JPEG" data-fancybox="images"><img src="../assets/images/gallery/gallery8.jpg" alt="Optimum Ambulance "></a>
                        </div>
                    </div>
                    <!--Single Gallery Image End-->
                    <!--Single Gallery Image Start-->
                    <div class="col-md-4 col-sm-6">
                        <div class="single-gallery-img mb--30">
                            <a href="../assets/images/gallery/gallerie6.png" data-fancybox="images"><img src="../assets/images/gallery/gallerie6.png" alt="Optimum Ambulance "></a>
                        </div>
                    </div>
                    <!--Single Gallery Image End-->
                </div>
            </div>
        </div>
        <!--Gallery Area End-->
        
    </main>
    <!--// Page Conttent -->
    <br><br><br><br><br>
    <!-- Footer Area -->

    <?php include("footer.php")?>