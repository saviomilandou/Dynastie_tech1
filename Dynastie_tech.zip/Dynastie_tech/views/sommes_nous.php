
   <?php  
     require_once("../models/model_general.php");

     require_once("../models/authentification/prise_rendez-vous.php");
     include("header.php");
     
    //  compter_visiter($_SERVER['REMOTE_ADDR'],"adhesion");

    //   $pays = all("pays");
  ?>

    <!-- Breadcrumb -->
    <div class="breadcrumb-area bg-secondary" data-bgimage="" data-black-overlay="4"> <img src="assets/images/slider/breadcrumb-bg-801.jpg" height="100%" alt=""> 
        
        <div class="container">
            <div class="in-breadcrumb">
                <div class="row">
                    <div class="col">
                        <h3>Qui sommes-nous ?</h3>
                        <!-- breadcrumb-list start -->
                        <ul class="breadcrumb-list">
                            <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                        
                            <li class="breadcrumb-item active">Apropos  </li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// Breadcrumb -->
    
    
    
    
    <!-- Page Conttent -->
    <main class="page-content section-ptb">
       <div class="container">
            <div class="row">
                <div class="col-lg-7 col-sm-12">
                    <div class="contact-form">
                        <div class="about-us-contents">
                            <div class="">
                             <h3><span> Optimum Ambulance </span> </h3>

                            </div>
                           
                        </div>
                    </div>
                <br>
                   <div> 
                       <div class="p-1 bg-info"><b><h4 class="text-white text-center">Notre Historique</h4></b></div>
                   <br>
  <p>OPTIMUM AMBULANCES, société par actions simplifiée, immatriculée sous le SIREN 528978281, est en activité depuis 11 ans. Implantée à IVRY-SUR-SEINE (94200), elle est spécialisée dans le secteur d'activité des ambulances.
     Son effectif est compris entre 6 et 9 salariés. Sur l'année 2018 elle réalise un chiffre d'affaires de 585 800,00 €. 
    Le total du bilan a augmenté de 11,66 % entre 2017 et 2018.
       Societe.com recense 2 établissements ainsi qu' un mandataire depuis le début de son activité, le dernier événement notable de cette entreprise date du 15-04-2016. Aymon LARIBI est président de l'entreprise OPTIMUM AMBULANCES</p>
</div>
        <br>

             <div class="p-1 bg-info"><b><h4 class="text-white text-center">Fondateur,Comité Consultatif</h4></b></div>

                </div>
                  <div class="col-lg-4 col-md-5 col-12 mx-auto">
                        <!-- single-choose-service -->
                        <div class="single-choose-service text-center mt--30">
                            <div class="service-icon ">
                                <img src="../assets/images/courses/ambulance.png" alt="Optimum ambulance">
                            </div>
                            <div class="service-content align-items-center">
                                <h5 class="text-secondary">Optimum Ambulance </h5>
                                <p class="text-secondary text-justify"> OPTIMUM AMBULANCES, société par actions simplifiée, immatriculée sous le SIREN 528978281, est en activité depuis 11 ans.
                                     Implantée à IVRY-SUR-SEINE (94200), elle est spécialisée dans le secteur d'activité des ambulances.
                                  Son effectif est compris entre 6 et 9 salariés. Sur l'année 2018 elle réalise un chiffre d'affaires de 585 800,00 €.
                                </p>
                            </div>
                        </div><!--// single-choose-service -->
                        <br><br>



<!-- single-choose-service -->
<div class="single-choose-service text-center mt--30">
        <div class="service-icon ">
            <img src="../assets/images/courses/ambulance.png" alt="Optimum ambulance">
        </div>
        <div class="service-content align-items-center">
            <h5 class="text-secondary">Optimum Ambulance </h5>
            <p class="text-secondary text-justify">OPTIMUM AMBULANCES, société par actions simplifiée, immatriculée sous le SIREN 528978281, est en activité depuis 11 ans.
                                     Implantée à IVRY-SUR-SEINE (94200), elle est spécialisée dans le secteur d'activité des ambulances.
                                  Son effectif est compris entre 6 et 9 salariés. Sur l'année 2018 elle réalise un chiffre d'affaires de 585 800,00 €.
            </p>
        </div>
    </div><!--// single-choose-service -->

<br><br>
<!-- single-choose-service -->
<div class="single-choose-service text-center mt--30">
        <div class="service-icon ">
            <img src="../assets/images/courses/ambulance.png" alt="Optimum ambulance">
        </div>
        <div class="service-content align-items-center">
            <h5 class="text-secondary">Optimum Ambulance</h5>
            <p class="text-secondary text-justify">OPTIMUM AMBULANCES, société par actions simplifiée, immatriculée sous le SIREN 528978281, est en activité depuis 11 ans.
                                     Implantée à IVRY-SUR-SEINE (94200), elle est spécialisée dans le secteur d'activité des ambulances.
                                  Son effectif est compris entre 6 et 9 salariés. Sur l'année 2018 elle réalise un chiffre d'affaires de 585 800,00 €.
             </p>
             </div>
                  </div><!--// single-choose-service -->


                    </div>
              </div>
        </div>
    </main>
    <!--// Page Conttent -->
    
    <!-- Footer Area -->
    <?php include("footer.php")?>