-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : lun. 27 juin 2022 à 09:47
-- Version du serveur : 5.7.33
-- Version de PHP : 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `dynastie_tech`
--

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

CREATE TABLE `contact` (
  `int` int(11) NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `objet` varchar(50) DEFAULT NULL,
  `message` text,
  `date_envoi` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `contact`
--

INSERT INTO `contact` (`int`, `nom`, `prenom`, `email`, `objet`, `message`, `date_envoi`) VALUES
(1, 'MILANDOU', 'Biani-Samuel', 'samuelbiani77@gmail.com', 'Prise de rendez-vous ', 'Je vous Ã©cris pour faire la demande du transport d\'une personne en maison d\'accueils ', '2022-06-14 17:03:59'),
(2, 'Mohaede ', 'Berland ', 'savio@gmail0com', 'Demande de transport Malade ', 'Information pour le transport des malades en maison de retraite ', '2022-06-14 19:14:34'),
(3, 'Mbanza ', 'Savio', 'Saviomilandou@gmail.com', 'Transport malade en maison de retraite ', 'Transport malade en maison de retraite ', '2022-06-14 19:28:52'),
(4, 'MILANDOU', 'CHRIST', 'saviomilandou@gmail.com', 'Demande de prise de rendez-vous ', 'Bienvenue ', '2022-06-15 01:13:11'),
(5, 'Savio ', 'Milandou', 'saviomilandou@gmail.com', 'Demande ', 'Bienvenue ', '2022-06-20 13:16:56');

-- --------------------------------------------------------

--
-- Structure de la table `newsletter`
--

CREATE TABLE `newsletter` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date_enregistrement` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`, `date_enregistrement`) VALUES
(1, 'saviomilandou@gmail.com', '2022-06-15 01:33:52'),
(2, 'jbmilandou@yahoo.fr', '2022-06-15 01:57:27'),
(3, 'bianisamuel@yahoo.fr', '2022-06-15 01:59:13');

-- --------------------------------------------------------

--
-- Structure de la table `prise_rendez_vous`
--

CREATE TABLE `prise_rendez_vous` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `sexe` varchar(50) DEFAULT NULL,
  `age` varchar(50) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `lieu_depart` varchar(250) NOT NULL,
  `lieu_arriver` varchar(250) NOT NULL,
  `email` varchar(50) NOT NULL,
  `accompagnateur` varchar(50) NOT NULL,
  `date_depart` datetime DEFAULT NULL,
  `date_retour` datetime DEFAULT NULL,
  `message` text NOT NULL,
  `date_envoi` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `prise_rendez_vous`
--

INSERT INTO `prise_rendez_vous` (`id`, `nom`, `prenom`, `sexe`, `age`, `telephone`, `adresse`, `lieu_depart`, `lieu_arriver`, `email`, `accompagnateur`, `date_depart`, `date_retour`, `message`, `date_envoi`) VALUES
(6, 'MILANDOU ', 'Christ Savio', 'Masculin', '20ans', '0641003686', '20 Avenue Henri Iv,Villeparisis', 'Villeparis', 'Paris75', 'Saviomilandou@gmail.com', 'Mohaede Berland', '2022-07-25 10:30:00', '2022-07-26 12:30:00', 'Prise de rendez-vous pour le transport d\'un malade ', '2022-06-14 19:27:07');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` int(11) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `passeword` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `date_envoi` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`int`);

--
-- Index pour la table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `prise_rendez_vous`
--
ALTER TABLE `prise_rendez_vous`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `contact`
--
ALTER TABLE `contact`
  MODIFY `int` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `prise_rendez_vous`
--
ALTER TABLE `prise_rendez_vous`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
